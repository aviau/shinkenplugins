
'''
Package which can be used by the tests of the plugins.
It contains some helpers classes, functions..
'''